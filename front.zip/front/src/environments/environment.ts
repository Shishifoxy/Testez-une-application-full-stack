export const environment = {
  baseUrl: 'localhost:8080/api/',
  production: false
};
