package com.openclassrooms.starterjwt.controllers;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.mockito.Mockito.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.openclassrooms.starterjwt.dto.SessionDto;
import com.openclassrooms.starterjwt.models.Session;
import com.openclassrooms.starterjwt.models.Teacher;
import com.openclassrooms.starterjwt.security.TestSecurityConfig;
import com.openclassrooms.starterjwt.services.SessionService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.http.MediaType;

import java.util.Date;
import java.util.Optional;

@SpringBootTest
@AutoConfigureMockMvc
@Import(TestSecurityConfig.class)
class SessionControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private SessionService sessionService;

    private ObjectMapper objectMapper;
    private Session testSession;

    @BeforeEach
    void setUp() {
        objectMapper = new ObjectMapper();
        testSession = new Session();
        testSession.setId(1L);
    }

    @Test
    void testGetSessionById_ShouldReturnSession_WhenExists() throws Exception {
        when(sessionService.getById(1L)).thenReturn(testSession);

        mockMvc.perform(get("/api/session/1"))
                .andExpect(status().isOk());
    }

    @Test
    void testFindAllSessions_ShouldReturnList() throws Exception {
        mockMvc.perform(get("/api/session"))
                .andExpect(status().isOk());
    }

    @Test
    void testUpdateSession_ShouldReturnUpdatedSession_WhenValidRequest() throws Exception {
        SessionDto sessionDto = new SessionDto();
        sessionDto.setId(1L);
        sessionDto.setName("Spring Boot Session");
        sessionDto.setDate(new Date());
        sessionDto.setDescription("Formation sur Spring Boot");
        sessionDto.setTeacher_id(1L); // ID du teacher

        Session updatedSession = new Session();
        updatedSession.setId(1L);
        updatedSession.setName("Spring Boot Session");
        updatedSession.setDate(sessionDto.getDate());
        updatedSession.setDescription("Formation sur Spring Boot");
        updatedSession.setTeacher(new Teacher().setId(1L)); // ou ce que ton mapper attend

        when(sessionService.update(eq(1L), any(Session.class))).thenReturn(updatedSession);

        mockMvc.perform(put("/api/session/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(sessionDto)))
                .andExpect(status().isOk());
    }

}